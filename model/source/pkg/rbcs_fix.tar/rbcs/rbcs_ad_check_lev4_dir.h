CADJ STORE rbct0 = tapelev4, key = ilev_4
CADJ STORE rbct1 = tapelev4, key = ilev_4
CADJ STORE rbcs0 = tapelev4, key = ilev_4
CADJ STORE rbcs1 = tapelev4, key = ilev_4

#ifdef ALLOW_PTRACERS
CADJ STORE rbcptr0 = tapelev4, key = ilev_4
CADJ STORE rbcptr1 = tapelev4, key = ilev_4
#endif
