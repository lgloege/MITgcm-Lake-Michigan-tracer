CADJ STORE rbct0 = tapelev3, key = ilev_3
CADJ STORE rbct1 = tapelev3, key = ilev_3
CADJ STORE rbcs0 = tapelev3, key = ilev_3
CADJ STORE rbcs1 = tapelev3, key = ilev_3

#ifdef ALLOW_PTRACERS
CADJ STORE rbcptr0 = tapelev3, key = ilev_3
CADJ STORE rbcptr1 = tapelev3, key = ilev_3
#endif
