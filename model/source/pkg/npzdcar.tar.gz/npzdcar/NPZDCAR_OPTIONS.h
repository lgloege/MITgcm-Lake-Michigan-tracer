C $Header: /u/gcmpack/MITgcm/pkg/npzdcar/NPZDCAR_OPTIONS.h,v 1.7 2006/01/02 21:17:01 heimbach Exp $
C $Name:  $
#include "PACKAGES_CONFIG.h"
#include "CPP_OPTIONS.h"
